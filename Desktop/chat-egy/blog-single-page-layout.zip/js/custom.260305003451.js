(() => {
  "use strict";

  const feed = document.getElementById("mainFeed");
  if (!feed) return;

  const cards = Array.from(feed.querySelectorAll(".reel-card"));
  const muteBtn = document.getElementById("globalMute");
  const installBtn = document.getElementById("installApp");
  const likesCount = document.getElementById("likesCount");
  const commentsCount = document.getElementById("commentsCount");
  const sharesCount = document.getElementById("sharesCount");
  const authorLine = document.getElementById("authorLine");
  const captionLine = document.getElementById("captionLine");
  const likeBtn = document.querySelector(".like-btn");

  let currentIndex = 0;
  let globallyMuted = false;
  let deferredInstallEvent = null;

  const readCount = (value) => Number.parseInt(value, 10) || 0;
  const formatCount = (value) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return `${value}`;
  };

  cards.forEach((card) => {
    card.dataset.likes = `${readCount(card.dataset.likes)}`;
    card.dataset.comments = `${readCount(card.dataset.comments)}`;
    card.dataset.shares = `${readCount(card.dataset.shares)}`;
    card.dataset.liked = "0";

    card.addEventListener("dblclick", () => {
      if (currentIndex !== Number(card.dataset.index)) return;
      toggleLike(true);
    });
  });

  const setCounts = (card) => {
    likesCount.textContent = formatCount(readCount(card.dataset.likes));
    commentsCount.textContent = formatCount(readCount(card.dataset.comments));
    sharesCount.textContent = formatCount(readCount(card.dataset.shares));
    authorLine.textContent = card.dataset.author;
    captionLine.textContent = card.dataset.caption;
    likeBtn.classList.toggle("active", card.dataset.liked === "1");
  };

  const playCard = (index) => {
    currentIndex = Math.max(0, Math.min(index, cards.length - 1));

    cards.forEach((card, i) => {
      const video = card.querySelector("video");
      if (!video) return;

      if (i === currentIndex) {
        video.muted = globallyMuted;
        video.play().catch(() => {});
      } else {
        video.pause();
      }
    });

    setCounts(cards[currentIndex]);
  };

  const scrollToIndex = (index) => {
    const safeIndex = Math.max(0, Math.min(index, cards.length - 1));
    cards[safeIndex].scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const toggleLike = (forceLike = false) => {
    const card = cards[currentIndex];
    const liked = card.dataset.liked === "1";
    const nextLiked = forceLike ? true : !liked;
    const likes = readCount(card.dataset.likes);
    const nextLikes = nextLiked ? likes + (liked ? 0 : 1) : Math.max(0, likes - 1);

    card.dataset.liked = nextLiked ? "1" : "0";
    card.dataset.likes = `${nextLikes}`;
    setCounts(card);
  };

  const increaseMetric = (metricKey) => {
    const card = cards[currentIndex];
    const current = readCount(card.dataset[metricKey]);
    card.dataset[metricKey] = `${current + 1}`;
    setCounts(card);
  };

  muteBtn?.addEventListener("click", () => {
    globallyMuted = !globallyMuted;
    muteBtn.textContent = globallyMuted ? "🔇" : "🔈";
    const video = cards[currentIndex]?.querySelector("video");
    if (video) {
      video.muted = globallyMuted;
      video.play().catch(() => {});
    }
  });

  likeBtn?.addEventListener("click", () => toggleLike(false));

  document.querySelector('[data-target="comments"]')?.addEventListener("click", () => {
    increaseMetric("comments");
    window.alert("هنا تقدر تربط نظام التعليقات الحقيقي (API + قاعدة بيانات).");
  });

  document.querySelector('[data-target="shares"]')?.addEventListener("click", async () => {
    increaseMetric("shares");
    const shareData = {
      title: "Reels Home Arab",
      text: "شوف الفيديو ده على reels.home-arab.chat",
      url: window.location.href
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (_) {}
      return;
    }

    try {
      await navigator.clipboard.writeText(window.location.href);
      window.alert("تم نسخ الرابط.");
    } catch (_) {
      window.alert("انسخ الرابط يدويًا من شريط العنوان.");
    }
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting || entry.intersectionRatio < 0.72) return;
        const nextIndex = Number(entry.target.dataset.index || 0);
        if (nextIndex !== currentIndex) playCard(nextIndex);
      });
    },
    { threshold: [0.72] }
  );

  cards.forEach((card) => observer.observe(card));

  feed.addEventListener(
    "wheel",
    (event) => {
      if (Math.abs(event.deltaY) < 18) return;
      event.preventDefault();
      scrollToIndex(currentIndex + (event.deltaY > 0 ? 1 : -1));
    },
    { passive: false }
  );

  document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown") scrollToIndex(currentIndex + 1);
    if (event.key === "ArrowUp") scrollToIndex(currentIndex - 1);
    if (event.key === "m" || event.key === "M") muteBtn?.click();
  });

  document.addEventListener("visibilitychange", () => {
    const video = cards[currentIndex]?.querySelector("video");
    if (!video) return;
    if (document.hidden) video.pause();
    else video.play().catch(() => {});
  });

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstallEvent = event;
    if (installBtn) installBtn.hidden = false;
  });

  installBtn?.addEventListener("click", async () => {
    if (!deferredInstallEvent) return;
    deferredInstallEvent.prompt();
    try {
      await deferredInstallEvent.userChoice;
    } catch (_) {}
    deferredInstallEvent = null;
    installBtn.hidden = true;
  });

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/service-worker.js").catch(() => {});
    });
  }

  playCard(0);
})();
